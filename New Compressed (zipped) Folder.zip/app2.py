import tkinter as tk
import os
import importlib.util
import xlsxwriter
import logging
import csv
import subprocess
from tkinter import messagebox


def tool():
    try:
        subprocess.run(["python", "tool.py"])
        messagebox.showinfo("Status", "Evaluation completed successfully.\nPlease check the result.log and result.xls files")
    except Exception as e:
        message = "Evaluation failed:\n" + str(e)
        messagebox.showinfo("Status", message)


def submit():
    text = entry.get()
    with open('textfile.txt', 'a') as file:
        file.write(text + '\n')
    text_area.config(state='normal')
    text_area.insert(tk.END, text + '\n')
    text_area.config(state='disable')

def reset():
    open('textfile.txt', 'w').close()
    open('id_numbers.txt', 'w').close()
    text_area.config(state='normal')
    text_area.delete(1.0, tk.END)
    text_area.config(state='disable')

def submit_id():
    id_numbers = id_entry.get()
    id_numbers_list = id_numbers.split(',')
    id_numbers_list = [int(i) for i in id_numbers_list]
    with open('id_numbers.txt', 'w') as id_file:
        id_file.write(f'id_numbers = {id_numbers_list}')


root = tk.Tk()
root.title("PyEvaluate v1.0.0")
root.wm_iconbitmap("C:\\Users\\rahul.gupta113\\Downloads\\snakes.ico")

label = tk.Label(root, text="Enter test cases:",fg = "black", bg = "cyan")
label.grid(row=0, column=0)

label1 = tk.Label(root, text="Enter test cases in the below format:\ntest_case_number;function_name;arguments;expected_output;test_case_marks\nExample:\n1;add;2,3;5;5\n2;add;2,2;4;10\n3;divide;10,2;5;20",fg = "black", bg = "cyan")
label1.grid(row=0, column=3)

entry = tk.Entry(root)
entry.grid(row=0, column=1)

submit_button = tk.Button(root, text="Add test case", command=submit,fg = "white", bg = "blue")
submit_button.grid(row=0, column=2)

id_label = tk.Label(root, text="Enter employee IDs:",fg = "blue", bg = "yellow",)
id_label.grid(row=1, column=0)

id_label1 = tk.Label(root, text="Enter employee IDs as csv(comma separated values):\nExample:\n1,2,3,4,5,6",fg = "blue", bg = "yellow")
id_label1.grid(row=1, column=3)

id_entry = tk.Entry(root)
id_entry.grid(row=1, column=1)

submit_id_button = tk.Button(root, text="Submit IDs", command=submit_id,fg = "white", bg = "blue")
submit_id_button.grid(row=1, column=2)

reset_button = tk.Button(root, text="Reset", command=reset,fg = "white", bg = "green")
reset_button.grid(row=2, column=2)



tool_button = tk.Button(root, text="Evaluate", command=tool,fg = "white", bg = "red")
tool_button.grid(row=3, column=3)


text_area = tk.Text(root)
text_area.grid(row=3, columnspan=3)
text_area.config(state='disable')

root.mainloop()
