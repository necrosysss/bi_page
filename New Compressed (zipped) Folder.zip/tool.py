import os
import importlib.util
import xlsxwriter
import logging
import csv

# Open the input file and read the data
with open('textfile.txt', 'r') as file:
    reader = csv.reader(file, delimiter=';')
    data = list(reader)

# Create a dictionary to store the test case marks
test_case_marks = {}

# Create a list to store the test case functions
test_case_functions = []

# Iterate over the data and extract the information
for row in data:
    # Extract the test case number, function name, arguments, and expected output
    test_case_number = row[0]
    function_name = row[1]
    arguments = tuple(map(int, row[2].split(',')))
    expected_output = int(row[3])
    test_case_mark = int(row[4])

    # Add the test case mark to the dictionary
    test_case_marks["test_case_" + test_case_number] = test_case_mark

    # Create the test case function
    test_case_function = f"def test_case_{test_case_number}():\n    return solution.{function_name}{arguments} == {expected_output}\n"
    test_case_functions.append(test_case_function)


# Open the output file and write the data
with open('part1.txt', 'w') as file:
    file.write("test_case_marks = {\n")
    for key, value in test_case_marks.items():
        file.write(f'    "{key}": {value},\n')
    file.write("}\n")


# Open the output file and write the data
with open('part2.txt', 'w') as file:
    for tc in test_case_functions:
        file.write(tc)








# Set up logging
logging.basicConfig(filename="results.log", level=logging.INFO, format="%(message)s")

# Create the Excel file
workbook = xlsxwriter.Workbook('results.xlsx')
worksheet = workbook.add_worksheet()

# Write the header row to the Excel file
worksheet.write(0, 0, "emp_id")

# Reading and executing the test case marks dictionary
with open('part1.txt', 'r') as file:
    code_1 = file.read()
    exec(code_1)

# Reading and executing the test case functions
with open('part2.txt', 'r') as file:
    code_2 = file.read()
    exec(code_2)

# Removing the redundant files
os.remove("part1.txt")
os.remove("part2.txt")

# Reading and executing the employee ids
with open('id_numbers.txt', 'r') as file:
    code = file.read()
    exec(code)

# Write the test case names to the Excel file
col = 1
for test_name, mark in test_case_marks.items():
    worksheet.write(0, col, test_name)
    col += 1
worksheet.write(0, col, "TOTAL")


# Write the log message for the start of the evaluation
logging.info("")
logging.info("**********STARTING EVALUATION*************")
logging.info("")

# Evaluate each trainee's solution and write the results to the Excel file
row = 1
for id in id_numbers:

    logging.info("")
    logging.info(f"----------evaluating traineee #{id}-----------")
    logging.info("")

    # Reset the solution module
    solution = None

    # Import the trainee's solution
    path = f"{id}/PART-B/solution.py"
    try:
        spec = importlib.util.spec_from_file_location("solution", path)
        solution = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(solution)
        logging.info(f"Successfully imported solution for emp_id {id}")
    except Exception as e:
        # Write the emp_id and total marks of 0 to the Excel file
        worksheet.write(row, 0, id)
        col = 1
        for test_name, mark in test_case_marks.items():
            worksheet.write(row, col, 0)
            col += 1
        worksheet.write(row, col, 0)
        # Log the error
        logging.error(f"Error importing solution for emp_id {id}: {e}")
        row += 1
        continue

    # Evaluate the trainee's solution
    try:
        total_marks = 0
        col = 1
        for test_name, mark in test_case_marks.items():
            if eval(test_name)():
                total_marks += mark
                worksheet.write(row, col, mark)
                logging.info(f"Test case {test_name} passed for emp_id {id}, marks: {mark}")
            else:
                worksheet.write(row, col, 0)
                logging.info(f"Test case {test_name} failed for emp_id {id}, marks: 0")
            col += 1
    except Exception as e:
        # Write the emp_id and total marks of 0 to the Excel file
        worksheet.write(row, 0, id)
        col = 1
        for test_name, mark in test_case_marks.items():
            worksheet.write(row, col, 0)
            col += 1
        worksheet.write(row, col, 0)
        # Log the error
        logging.error(f"Error evaluating solution for emp_id {id}: {e}")
        row += 1
        continue

    # Write the emp_id and total marks to the Excel file
    worksheet.write(row, 0, id)
    worksheet.write(row, col, total_marks)
    logging.info(f"Total marks for emp_id {id}: {total_marks}")
    row += 1

# Close the Excel file
workbook.close()


logging.info("")
logging.info("**********EVALUATION COMPLETE*************")